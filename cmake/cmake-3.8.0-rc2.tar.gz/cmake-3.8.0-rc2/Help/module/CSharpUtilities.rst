.. cmake-module:: ../../Modules/CSharpUtilities.cmake
