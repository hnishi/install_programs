.. cmake-module:: ../../Modules/FindLua51.cmake
